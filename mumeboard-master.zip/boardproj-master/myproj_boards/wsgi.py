"""
WSGI config for myproj_boards project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/2.2/howto/deployment/wsgi/
"""

import os
import sys

from django.core.wsgi import get_wsgi_application
#以下二行はデプロイ後のやつ。
settings_path = '/home/yuika11/yuika11.pythonanywhere.com/myproj_boards'
sys.path.insert(0, settings_path)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myproj_boards.settings')

application = get_wsgi_application()

//　https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=35.7217636,139.4667473&radius=2000&keyword=快活クラブORグランサイバーカフェバグースORマンボーORカスタマカフェORコミックバスターORネットカフェジャムOR自遊空間&language=ja&key=AIzaSyAiV2ZbFIYuD3N4hzGLstSn2e4ZG5A7QlU

//　1

kodaira_netcafe = {
   "html_attributions" : [],
   "results" : [
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.7320197,
               "lng" : 139.465549
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.73336952989272,
                  "lng" : 139.4668988298927
               },
               "southwest" : {
                  "lat" : 35.73066987010727,
                  "lng" : 139.4641991701072
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "JAM小平店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 2160,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/118252634782609753961\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBmamAHqUfSrSEDOM6F_rIbtM6srB7LMO1v6E0jfwMGNAxVz31sn_WQ1MAqaRX3PnV7cXHShtmXPkHa5KxIdajrK9dkv2Nffrq7OlfTyiG774IC37ijj9TB95aE-Qm_7gydQ0UEPNgnEf1M7oaPEXQhjXgn_NCwMS9lfI5-O87lOnlh",
               "width" : 3840
            }
         ],
         "place_id" : "ChIJjVjdSsDmGGARGsk2T_Y97X8",
         "plus_code" : {
            "compound_code" : "PFJ8+R6 小平市、東京都",
            "global_code" : "8Q7XPFJ8+R6"
         },
         "rating" : 3.8,
         "reference" : "ChIJjVjdSsDmGGARGsk2T_Y97X8",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 30,
         "vicinity" : "小平市小川町2−２０６２−１ 2F"
      }
   ],
   "status" : "OK"
}

//　https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=35.690921,139.7002579&radius=300&keyword=カラオケ館ORカラオケマックORジョイサウンドORカラオケの鉄人ORカラオケパセラORカラオケバンバンOR歌広場ORワンカラORビックエコーORまねきねこORコロッケ倶楽部&language=ja&key=AIzaSyAiV2ZbFIYuD3N4hzGLstSn2e4ZG5A7QlU


shinjuku_karaoke = {
   "html_attributions" : [],
   "next_page_token" : "Aap_uECS_uOv4Fn_l65Sskj3JM79g7RczYMQv5bn2xc38xnuD9W62xbs0ziKe63ZZzPRRSXBQq4JS-yhh4MdTWTRDbMMgsYj_vRMIJLY_2FQ_D1-jUijvHEVDlASgrvCkbkVuRAi9T1xlGKX72O31X_mMuJcoMSnjmx42ui-ViZH9kX-jOB3rEFfHnI59_F6jsVfdrzYek5vroN-nPQ3m1ynT_AoCkx2UKF0fqgKZPriDL1tNNyPZoxbhapiSl5x-uP_q50FQehHT7H89dvLnCCUoRX1CQcXDVM2aVMBBJxnU8DLAZ2EhpNYS24pLms0oH-tF-0N-56OKGx348rsUIK3YF1cG2fdVQ9OILsm5SkexZVDZ3PmWuR0SiyYyb4paGNsXCvjkWRtn9keIFJqKvJIlIFhibQN9lM9NQbpKUitprjh3yP2PO1Zah9OdboKbOLaHFDcsg7qDxvvsTCeivY6rdRY0lYZTCfA4XC5uvaHmTefd_CAHJe_TahBghyrwnjlDUfmyGA_wH1RFU0hwUQAA5n6FmfvpSYW2v--gj1Z2VAyX1r-c5GETVBmEPxCbQWl63r19si9Au8RGjYuROTkLR-B6ssTP3OwhanDho6iNYHf6DbE9PA8mo3INipwvpF-rFhq_Wyl7fm5MH4oeDpIURqjoQ6e56RP7vVL86cTE-yGpiPuSx5CgxOnAtFeDxu6lyKldmkSRssDl-F85jtOW6BvcGT0sFtsfZoga_9GcKbhcxgbXrW-m4ciulZ_t2zaspUfr6QUrn0QvUgtfeeqM0ZoFKucW6qRO2keA0wdi1qz55xENClNJMNJBD7HBIA9xidq8r2Yc-NWFZ_AVh-8nt5wk46DSVrdnBQgOaH_w4CrWMkR12gMT_4AB56q1gluSTR-MLLqNzBDH8GS_t9lTWe0p-EuUwUdZHKxVotv09li-RnvH4GiHS3GQ03sgI1PRg5cV3ag4jKJuKk90oESrfFSRMmysAvDpyYJ80iD3D4KpInPGubNizPiGMblepti1d4",
   "results" : [
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6913643,
               "lng" : 139.7020603
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69271412989272,
                  "lng" : 139.7034101298927
               },
               "southwest" : {
                  "lat" : 35.69001447010728,
                  "lng" : 139.7007104701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ ビッグエコー新宿東口駅前店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 480,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/112222927138210698390\"\u003eビッグエコー新宿東口店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEDwBQtWT_H0ugRESnHXKB2uAbY6tCLBT6wbmZJSvz9iP_do283ttglyZhUqXZ1cbgZzwKCjL9B8J_FzgzWcjGmI0bntTfPuPO1KYJdNHUEt87p7AxxdB9oXwejHoNY1di-Oerd2ss7CYuvMBEeddteB2MjpJce_3K-n5n9ybzdLo-LD",
               "width" : 480
            }
         ],
         "place_id" : "ChIJQ5SMEtqMGGARcwFjKMfYUb4",
         "plus_code" : {
            "compound_code" : "MPR2+GR 新宿区、東京都",
            "global_code" : "8Q7XMPR2+GR"
         },
         "price_level" : 3,
         "rating" : 3.4,
         "reference" : "ChIJQ5SMEtqMGGARcwFjKMfYUb4",
         "scope" : "GOOGLE",
         "types" : [ "night_club", "bar", "point_of_interest", "establishment" ],
         "user_ratings_total" : 245,
         "vicinity" : "新宿区新宿３丁目２６−２ Motoビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6892388,
               "lng" : 139.6974924
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69059612989272,
                  "lng" : 139.6988652798927
               },
               "southwest" : {
                  "lat" : 35.68789647010728,
                  "lng" : 139.6961656201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケマック西新宿店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 1536,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/115641038876430896472\"\u003eカラオケマック西新宿店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAJjLD2lhcdL6q4Y3L1WQuDVDty_Y74hwHZ_lLhdkHDJ_0tzBsYCoap7dT22px7K7lMVD6dxiD9JGI3n1Z5oEPDgXEIcCiiSDaLxIPGK3Srz63oZxkreJ6KAvTS8YyxUd7UPaIZQ_HL5AKZLuPsEYQMqk4pPR7eo8_vQvAa1BzE_mcZ",
               "width" : 2048
            }
         ],
         "place_id" : "ChIJeSuqa9GMGGARZedV0zCS0QY",
         "plus_code" : {
            "compound_code" : "MMQW+MX 新宿区、東京都",
            "global_code" : "8Q7XMMQW+MX"
         },
         "rating" : 3.7,
         "reference" : "ChIJeSuqa9GMGGARZedV0zCS0QY",
         "scope" : "GOOGLE",
         "types" : [ "night_club", "bar", "point_of_interest", "establishment" ],
         "user_ratings_total" : 148,
         "vicinity" : "新宿区西新宿１丁目１５−１ 桜木ビル 2F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6917967,
               "lng" : 139.7023599
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69314652989273,
                  "lng" : 139.7037097298928
               },
               "southwest" : {
                  "lat" : 35.69044687010729,
                  "lng" : 139.7010100701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新宿東口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 405,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/108187544724082149715\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEDBYbHr2FM-WYc20fu0qveA14VYb4HY-oa9_kumWAEu4oUxKG5xhXbGx8Q2xU6vKOORRx8zF98rpJ6QjLtjdbFS5w7ZDQYKVPMGA4BFFLUpzAn2CTuD8KgCVEHvMSZLIm0pC3MjoC8lbddvCy5ylOGIvzzFovOxHRqHSC4_Gi2eAPIX",
               "width" : 720
            }
         ],
         "place_id" : "ChIJJ6dKEdqMGGARllLElZjygcc",
         "plus_code" : {
            "compound_code" : "MPR2+PW 新宿区、東京都",
            "global_code" : "8Q7XMPR2+PW"
         },
         "price_level" : 3,
         "rating" : 3.2,
         "reference" : "ChIJJ6dKEdqMGGARllLElZjygcc",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 252,
         "vicinity" : "新宿区新宿３丁目２６−１４ 新宿Mmビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6929663,
               "lng" : 139.69904
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69431612989273,
                  "lng" : 139.7003898298927
               },
               "southwest" : {
                  "lat" : 35.69161647010729,
                  "lng" : 139.6976901701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "ビッグエコー 新宿西口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 2160,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/118252634782609753961\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEB6Db5sqkgujOiU-Nl--IaPTqJlIYdV9Idpd6u_jZTmUpWCuJlkBc0Z3niCeArL8Lu1lZleFEjQg1vnAFTIdmk-USkQiM44RuGwsrp19guqmnHf0n2s5BFj8D6NeHcPrvZjShIJgm2mlWQ9i5sEnxaJaoDF3-wcHjkrLDgy7xfP2bQu",
               "width" : 3840
            }
         ],
         "place_id" : "ChIJod8fA9eMGGARY7vFPCcLEpM",
         "plus_code" : {
            "compound_code" : "MMVX+5J 新宿区、東京都",
            "global_code" : "8Q7XMMVX+5J"
         },
         "price_level" : 3,
         "rating" : 3.2,
         "reference" : "ChIJod8fA9eMGGARY7vFPCcLEpM",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 177,
         "vicinity" : "新宿区西新宿１丁目４−１ 1・2F プリンスビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.693909,
               "lng" : 139.699379
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69516117989272,
                  "lng" : 139.7007221798927
               },
               "southwest" : {
                  "lat" : 35.69246152010728,
                  "lng" : 139.6980225201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "ワンカラ 新宿大ガード店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3456,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/115283530710614345032\"\u003eホロ\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uED4An_jShKLV_pygpR6WVPVJRz_dfa705z7wp-vGt8rT9FyZFnKhgMlZlbA-OUQcps6hPowp7LmmaKk6fbn2fUYez7VE9uPMJwy_YaHrIhA54JKNLrmI6sNpQTHm9qyF-Vi3b3d_zzoSU5MtcfXmbaT7b1aZBNS14HLOn3hb8upgvLq",
               "width" : 4608
            }
         ],
         "place_id" : "ChIJ9Qs3D9eMGGARfz3hBRxXGT4",
         "plus_code" : {
            "compound_code" : "MMVX+HQ 新宿区、東京都",
            "global_code" : "8Q7XMMVX+HQ"
         },
         "rating" : 4,
         "reference" : "ChIJ9Qs3D9eMGGARfz3hBRxXGT4",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 243,
         "vicinity" : "新宿区西新宿１ ７丁目１−１ 新宿カレイドビル 4F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6934909,
               "lng" : 139.703043
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69484072989272,
                  "lng" : 139.7043928298927
               },
               "southwest" : {
                  "lat" : 35.69214107010728,
                  "lng" : 139.7016931701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新宿靖国通り店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 405,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/103505081821028858669\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAFC73UONv60VFtjT0JxO1g6Uk53TuNbeN--N_1T939LI9k8fW_M1nVjZp1-1pehDGm5cRJ5sW0fToGcvi6VNw0lAL5A9dxLNI3SIFnskmeQufjHav0n9JndwsLJ-wrzFotGyH9H6bbK_o4mttI2mDfq_rCmUy_dAknwZrIuQckPSEK",
               "width" : 720
            }
         ],
         "place_id" : "ChIJzd-2kdmMGGARio50Mt-4JVA",
         "plus_code" : {
            "compound_code" : "MPV3+96 新宿区、東京都",
            "global_code" : "8Q7XMPV3+96"
         },
         "price_level" : 3,
         "rating" : 3.2,
         "reference" : "ChIJzd-2kdmMGGARio50Mt-4JVA",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 149,
         "vicinity" : "新宿区歌舞伎町１丁目５−７ 歌舞伎町Ｂ＆Ｖビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6894302,
               "lng" : 139.6966516
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69073487989272,
                  "lng" : 139.6979533298927
               },
               "southwest" : {
                  "lat" : 35.68803522010727,
                  "lng" : 139.6952536701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "ビッグエコー 西新宿センター店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 480,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/101636885467871510061\"\u003eビッグエコー 西新宿センター店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECqXOESJrymH_t6BIIWYQ60u2LBR4fCGWXlJc3PJG5rovU8pMIuFQDzRPHRNp772eIvgdur59E0UX6StTgB4X9GeRZabL-I9uDE7_UOcGlkoQI3Ut8Zemf2l6T59Q0Nn-LtkxiZmG4l0RZ-ex5KQbTujI1WEUE4b2JpKZP7cQ6uLMCV",
               "width" : 640
            }
         ],
         "place_id" : "ChIJcdVwW9GMGGARknWgpjNmqI4",
         "plus_code" : {
            "compound_code" : "MMQW+QM 新宿区、東京都",
            "global_code" : "8Q7XMMQW+QM"
         },
         "price_level" : 3,
         "rating" : 3.6,
         "reference" : "ChIJcdVwW9GMGGARknWgpjNmqI4",
         "scope" : "GOOGLE",
         "types" : [ "night_club", "bar", "point_of_interest", "establishment" ],
         "user_ratings_total" : 87,
         "vicinity" : "新宿区西新宿１丁目１３−６"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6927807,
               "lng" : 139.6979675
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69415757989272,
                  "lng" : 139.6993098298927
               },
               "southwest" : {
                  "lat" : 35.69145792010728,
                  "lng" : 139.6966101701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新宿店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 400,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/102805298380040673115\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECPYVasVh_mOJv3ygWq7tbaa7BKl3v1sJakRFk0Rfm6fPtuCbJCClkPpX17xgH3qUZc4ruQ5PU4w7HPf4OFzmDV-DoXofH0UqbBcOJ3xZ7XACR2SlbQEW37hxZHuZFZc402fqsDd7Ssnkd0lI8JCJu2cTYHSgFHsQTjPB-IlZr1MF5-",
               "width" : 650
            }
         ],
         "place_id" : "ChIJUwzT9taMGGAR4XwtMqIh4PA",
         "plus_code" : {
            "compound_code" : "MMVX+45 新宿区、東京都",
            "global_code" : "8Q7XMMVX+45"
         },
         "price_level" : 3,
         "rating" : 3.3,
         "reference" : "ChIJUwzT9taMGGAR4XwtMqIh4PA",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 190,
         "vicinity" : "新宿区西新宿１丁目５−１２ 北新宿ビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6900125,
               "lng" : 139.7030308
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69130467989272,
                  "lng" : 139.7044620298927
               },
               "southwest" : {
                  "lat" : 35.68860502010727,
                  "lng" : 139.7017623701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿東南口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3456,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/100789150857758761653\"\u003etaichi matsuo\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECR-bW7-Tbhk7aQBjHNQQa_LWSRMCwYqy3T8bUtWiW5U5onxbF2-gr5UKMPc1qZpUJNqIVHUu1jS_Bhdbwp4T_hZhW7qsAxpMkTUZgAa6BWcr4J1MdXOCJgUn7--TnElygkXd-jgNnFeWC9tut16QUENCLnCJtSSw0K9w2Txq1cQR5y",
               "width" : 4608
            }
         ],
         "place_id" : "ChIJ_7ZP7tqMGGAR5WDJ8g7KYRc",
         "plus_code" : {
            "compound_code" : "MPR3+26 新宿区、東京都",
            "global_code" : "8Q7XMPR3+26"
         },
         "rating" : 3.5,
         "reference" : "ChIJ_7ZP7tqMGGAR5WDJ8g7KYRc",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 158,
         "vicinity" : "新宿区新宿３丁目３５−１８ 東南口ビル4F・6F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6937284,
               "lng" : 139.7020481
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69507822989272,
                  "lng" : 139.7033979298927
               },
               "southwest" : {
                  "lat" : 35.69237857010727,
                  "lng" : 139.7006982701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケパセラ新宿靖国通り店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3968,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/113649764698114210758\"\u003e小川敦子\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEDDqnrL7rHNywiE4ciMEdLJm36PMXvChiwe-2FEN-9bTSc5qPJsbH5jaJ6B1eqzbSA2cRapvDhw49qMs1dW7vIJEiNXiGX-D7Nr2_b99-wmG106R7KKhYGdQoSpMYsZn_pbKy9f8_MecmYOQlbsvQpPSzekoC44GqccDoTTigAk4j3d",
               "width" : 2976
            }
         ],
         "place_id" : "ChIJxWXywtmMGGARzvLeUd-eb0A",
         "plus_code" : {
            "compound_code" : "MPV2+FR 新宿区、東京都",
            "global_code" : "8Q7XMPV2+FR"
         },
         "price_level" : 3,
         "rating" : 4,
         "reference" : "ChIJxWXywtmMGGARzvLeUd-eb0A",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 301,
         "vicinity" : "新宿区歌舞伎町１丁目１６−２ パセラリゾーツ新宿靖国通り店１Ｆ"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6898295,
               "lng" : 139.6973197
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69118367989272,
                  "lng" : 139.6987618298927
               },
               "southwest" : {
                  "lat" : 35.68848402010727,
                  "lng" : 139.6960621701072
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "ジョイサウンド 新宿西口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3072,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/117347621100845170199\"\u003eSong-yang Tong\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uED8uMtdX2S_MXjRZEbGvdkiY_cZL_QWcAK_rTVatcREkavNFNFZoIS9sRogNNJYfUPTRpQNX58TShR_VHatHxjWe-K3nKMFrmKA_F-Ea78ScUKN58uGVrGOov-5buCyEsNzLOTsiVP_bmlfHJvitIStvbsNWsPFIYcHsI17BV7iN3Wf",
               "width" : 4608
            }
         ],
         "place_id" : "ChIJ1UDaR9GMGGARQXifFuBBgQg",
         "plus_code" : {
            "compound_code" : "MMQW+WW 新宿区、東京都",
            "global_code" : "8Q7XMMQW+WW"
         },
         "price_level" : 3,
         "rating" : 3.7,
         "reference" : "ChIJ1UDaR9GMGGARQXifFuBBgQg",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 249,
         "vicinity" : "新宿区西新宿１丁目１２−１ 高倉第一ビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.688513,
               "lng" : 139.6994319
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.68986282989272,
                  "lng" : 139.7007817298928
               },
               "southwest" : {
                  "lat" : 35.68716317010728,
                  "lng" : 139.6980820701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケルーム歌広場 新宿南口駅前店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3648,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/115990071035864670515\"\u003eカラオケルーム歌広場 新宿南口本館\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBjL6wI7gEkxvpR9elVdtKk4oTakPeEjVgPKMJM4N_V65-VvLOSZciNSZGmqJS0o1lYKQOsaxdy6SIlX1H49dtetRa4IovbndoOxRuru-D94vI6DUCOt8MQwqa9G5gK2iv2ymWxTccfGCsUeaUBxEahenpj7nukOe8Yv5Zmbm1s3l-q",
               "width" : 5472
            }
         ],
         "place_id" : "ChIJNW0QUNCMGGARMGXRzfrchPI",
         "plus_code" : {
            "compound_code" : "MMQX+CQ 渋谷区、東京都",
            "global_code" : "8Q7XMMQX+CQ"
         },
         "price_level" : 2,
         "rating" : 3.5,
         "reference" : "ChIJNW0QUNCMGGARMGXRzfrchPI",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 205,
         "vicinity" : "渋谷区代々木２丁目８−６ 新宿駅前サウスビル 7階"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6934041,
               "lng" : 139.7037577
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69475392989272,
                  "lng" : 139.7051075298927
               },
               "southwest" : {
                  "lat" : 35.69205427010728,
                  "lng" : 139.7024078701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケルーム歌広場 新宿区役所前店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3648,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/116818028627649411583\"\u003eカラオケルーム歌広場 新宿区役所前店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAfkPVKIx0Y9NwTPVJjZwW1rNkzTPghzLR8zNeUMIRTi5JS3IvLqU52WAlhPcMBq1kRngab108jFGA75RqTMcvMn7q0vz-CT3ncyY6mUzZTF8TT7rfJd4m5vsbzu6K5RclsZ5f8yP8tR3Q3ARtsfns_qhs5EbXQoHsaD6aFQi9hNrs",
               "width" : 5472
            }
         ],
         "place_id" : "ChIJ4WyHgdmMGGARjVLmFJDNizU",
         "plus_code" : {
            "compound_code" : "MPV3+9G 新宿区、東京都",
            "global_code" : "8Q7XMPV3+9G"
         },
         "price_level" : 2,
         "rating" : 3.4,
         "reference" : "ChIJ4WyHgdmMGGARjVLmFJDNizU",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 170,
         "vicinity" : "新宿区歌舞伎町１丁目２−番2号 歌舞伎町ビル 1階 エイチ・エフ"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6943569,
               "lng" : 139.7015462
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69568652989272,
                  "lng" : 139.7029924298927
               },
               "southwest" : {
                  "lat" : 35.69298687010728,
                  "lng" : 139.7002927701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 歌舞伎町本店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 405,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/108983917403399277396\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAMhsE-RQz6q1OLMAl7aRyouEdxJlrhIt1-GrN_qajaeFo1StZ5ZZ6t-5qi93XZ-4lDo6eI1YKhdpoQR8bcTvSk8dOnqeF2_ElOSpDT3kSsBZkasZGBSTiBxmNkUsAqGOrlqTEe_jRLg6HvhskmGyeGrkOQmOE_DsSmLWHTVTlWZ_1Q",
               "width" : 720
            }
         ],
         "place_id" : "ChIJyZc01NmMGGAR5Jg4PX9I7e0",
         "plus_code" : {
            "compound_code" : "MPV2+PJ 新宿区、東京都",
            "global_code" : "8Q7XMPV2+PJ"
         },
         "price_level" : 3,
         "rating" : 3.5,
         "reference" : "ChIJyZc01NmMGGAR5Jg4PX9I7e0",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 147,
         "vicinity" : "新宿区歌舞伎町１丁目１７−１０ CR,B&Vビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.68838480000001,
               "lng" : 139.6971154
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.68977912989273,
                  "lng" : 139.6983886298927
               },
               "southwest" : {
                  "lat" : 35.68707947010728,
                  "lng" : 139.6956889701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 西新宿店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 400,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/116702601290168416148\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBa2xnyaVPnXBHm-SDu8ZAHQ0yreuu2lKC5OGzBt1l5O4UBPOyGDDzv936yir4sZHuvOk_MuQ3D9qI2FnjgTc91u45WTymbCboR8fbYqgUXjafE0v75AXngZzzEFRXVurUpsAW7MRrYdu9Q18SXwA5iPHWw1_voight_7Nr0fP9vBHM",
               "width" : 650
            }
         ],
         "place_id" : "ChIJGfTTdtGMGGAR8ka_pEf7kb0",
         "plus_code" : {
            "compound_code" : "MMQW+9R 新宿区、東京都",
            "global_code" : "8Q7XMMQW+9R"
         },
         "price_level" : 3,
         "rating" : 3.5,
         "reference" : "ChIJGfTTdtGMGGAR8ka_pEf7kb0",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 205,
         "vicinity" : "新宿区西新宿１丁目１９−１４ Ｂ＆Ｖ西新宿ビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.693287,
               "lng" : 139.6989519
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69463682989272,
                  "lng" : 139.7003017298927
               },
               "southwest" : {
                  "lat" : 35.69193717010728,
                  "lng" : 139.6976020701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケの鉄人 新宿大ガード店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 1091,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/113915796400321144075\"\u003e【新宿・新宿西口・大ガードのカラオケ店】 カラオケの鉄人 新宿大ガード店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAUR0l4nd5u0RFB6suUx4CRx9U9g2cYIgcbHg5dnZwcLgPlpkrNKUx-ImjOGbsX71tgU0BMfBCC2_2GHGPdgy4vAJFF5iFY6mpTx8xNEDs3DfDfb7zXxCYDaJvrUhOjPzdO4yn3LV4hulPbo292YZH1364jtt0bppg5lfd9c3VGt8CK",
               "width" : 1635
            }
         ],
         "place_id" : "ChIJM4gKAdeMGGARZDBO2lxRa90",
         "plus_code" : {
            "compound_code" : "MMVX+8H 新宿区、東京都",
            "global_code" : "8Q7XMMVX+8H"
         },
         "price_level" : 3,
         "rating" : 3.2,
         "reference" : "ChIJM4gKAdeMGGARZDBO2lxRa90",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 288,
         "vicinity" : "新宿区西新宿１丁目３−２ ヨドバシ大ガードビル 1-9F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.69321559999999,
               "lng" : 139.698967
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69456542989272,
                  "lng" : 139.7003168298927
               },
               "southwest" : {
                  "lat" : 35.69186577010728,
                  "lng" : 139.6976171701072
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿西口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3000,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/107931988485181902859\"\u003e中善寺なき子\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uED3Zr6hmfQKOwD7eSeyOlO9ouN8iAT7Y-C3I18smd5-_ZeiCsVtXv6R_ssdkCMG0E7pyxvBU2evC43yeXI0Y3j7LiBGDAfoDqKmNfC-smCHXVTrODiXnnVG4e3oMtGJoO3xIghZ2ynGvPMUrRe-bEVfAE-a2pPUcTNOCPhkRCBcArZu",
               "width" : 4000
            }
         ],
         "place_id" : "ChIJSR0pkVKNGGARh51UKrQTuYU",
         "plus_code" : {
            "compound_code" : "MMVX+7H 新宿区、東京都",
            "global_code" : "8Q7XMMVX+7H"
         },
         "rating" : 3.6,
         "reference" : "ChIJSR0pkVKNGGARh51UKrQTuYU",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 185,
         "vicinity" : "新宿区西新宿１丁目３−１ １Ｆ・Ｂ１Ｆ 品川ステーションビル 新宿"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6937288,
               "lng" : 139.7039814
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69507862989272,
                  "lng" : 139.7053312298927
               },
               "southwest" : {
                  "lat" : 35.69237897010728,
                  "lng" : 139.7026315701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿歌舞伎町１号店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3264,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/102678984446632354721\"\u003eつかさ 大島\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECnSQgDgP6tHIdBYdjZWMEUS4jAMvoMaA6vDkt4ZIfpEcDt_9ZICiQcpPHbC-qY0aWXfQPlP_86upnIiRl7-QuowYpblFSNeNLqaVQ1fMY4k1x05Ku6hbSKndD71QvS84BCtcrSjtWIZoPkjYcZwf_PUdofwndBj1OQrZI8hErU1NNO",
               "width" : 2048
            }
         ],
         "place_id" : "ChIJh1c8eNmMGGARKpLkuD8Poms",
         "plus_code" : {
            "compound_code" : "MPV3+FH 新宿区、東京都",
            "global_code" : "8Q7XMPV3+FH"
         },
         "rating" : 3.7,
         "reference" : "ChIJh1c8eNmMGGARKpLkuD8Poms",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 92,
         "vicinity" : "新宿区歌舞伎町１丁目２−５ 東陽ビル 5F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.694877,
               "lng" : 139.7023938
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69622682989272,
                  "lng" : 139.7037436298927
               },
               "southwest" : {
                  "lat" : 35.69352717010727,
                  "lng" : 139.7010439701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新・歌舞伎町店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 400,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/117217048708598344718\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAi6WywUcH2QSly4pFecF2ePsHmZTIbAKxnh0tyJlyjj1eGjU2yqkrjZRRY742tC1iZNKohOYyK1_FJVcXp1r8R8cFHyo055MEeqQf3ewrV4Ykiwgh3fF1cbDAODHzfLuy6oze3qo2KVsuXoGKo05IokwmE725hqJ3mkDSXcgvsJkDQ",
               "width" : 650
            }
         ],
         "place_id" : "ChIJJRC2NNiMGGARmp2RdgYEzCU",
         "plus_code" : {
            "compound_code" : "MPV2+XX 新宿区、東京都",
            "global_code" : "8Q7XMPV2+XX"
         },
         "price_level" : 3,
         "rating" : 3.1,
         "reference" : "ChIJJRC2NNiMGGARmp2RdgYEzCU",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 31,
         "vicinity" : "新宿区歌舞伎町１丁目１２−３ 第二Ｂ＆Ｖビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.69304450000001,
               "lng" : 139.7015442
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69439432989272,
                  "lng" : 139.7028940298927
               },
               "southwest" : {
                  "lat" : 35.69169467010728,
                  "lng" : 139.7001943701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿東口店",
         "opening_hours" : {
            "open_now" : true
         },
         "place_id" : "ChIJ5zjzg-aNGGARVbR8FpemSBI",
         "plus_code" : {
            "compound_code" : "MPV2+6J 新宿区、東京都",
            "global_code" : "8Q7XMPV2+6J"
         },
         "rating" : 5,
         "reference" : "ChIJ5zjzg-aNGGARVbR8FpemSBI",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 1,
         "vicinity" : "新宿区新宿３丁目２２−３ １～４Ｆ 三憩ビル"
      },

      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.69432219999999,
               "lng" : 139.7038617
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69563262989271,
                  "lng" : 139.7052730298927
               },
               "southwest" : {
                  "lat" : 35.69293297010727,
                  "lng" : 139.7025733701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケパセラ新宿本店",
         "opening_hours" : {
            "open_now" : false
         },
         "photos" : [
            {
               "height" : 3385,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/113971147995617142649\"\u003eカラオケ パセラ 新宿本店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAgn5E0bquEAHpAH-XQonvjfpYcQIOtz6Bq8LVpX9FBF8jN7Rs4PHPDsF84zEuUX3lBQthLmpRgxjOmDLs44YFTLjcu2nYSp8cItPz3Efr8kvrQQyEEkb5-3FD-sUM5m7QqqgyqEyjrP3cPcK-ynCqkmvVhP6xwKDpGwZ1pulZh2-_Q",
               "width" : 5077
            }
         ],
         "place_id" : "ChIJj3M-oNmMGGAROsKvPMOxT_o",
         "plus_code" : {
            "compound_code" : "MPV3+PG 新宿区、東京都",
            "global_code" : "8Q7XMPV3+PG"
         },
         "price_level" : 3,
         "rating" : 3.9,
         "reference" : "ChIJj3M-oNmMGGAROsKvPMOxT_o",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 490,
         "vicinity" : "新宿区歌舞伎町１丁目３−１６ パセラリゾーツ新宿本店１Ｆ"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6940483,
               "lng" : 139.6993433
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69545092989271,
                  "lng" : 139.7007307798928
               },
               "southwest" : {
                  "lat" : 35.69275127010727,
                  "lng" : 139.6980311201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿大ガード店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3072,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/107931988485181902859\"\u003e中善寺なき子\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBqztiQCZ8PSL1geu_a_z4w3uXQ5mkGBdL2YdJghPSpreniAcNzophyINw0Vk5LBN8vHZItBS_uiW5fsn8GKjpuMWUzNFelhfWt4VG8yskyNVvAeveCZkLpRWFkqxZh0TObMQbkVWc6ZmvLWNYEiLYpvUqYmskvlWyljPNwDupCOGaS",
               "width" : 4096
            }
         ],
         "place_id" : "ChIJmW3Or9eMGGAR20cVRTcE-8Y",
         "plus_code" : {
            "compound_code" : "MMVX+JP 新宿区、東京都",
            "global_code" : "8Q7XMMVX+JP"
         },
         "rating" : 3.4,
         "reference" : "ChIJmW3Or9eMGGAR20cVRTcE-8Y",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 99,
         "vicinity" : "新宿区西新宿７丁目１−１ 新宿カレイドビル 4F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.695382,
               "lng" : 139.701152
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69688702989271,
                  "lng" : 139.7025129798927
               },
               "southwest" : {
                  "lat" : 35.69418737010727,
                  "lng" : 139.6998133201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケルーム歌広場 新宿歌舞伎町店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3648,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/105554092367700786501\"\u003eカラオケルーム歌広場 新宿歌舞伎町２号店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEB7sO0wmagZjsJNQc8egXJARigoRsjggF7AZB5npNEGzDTsX6pHHi69fRExlAqXH-_4I8q_mr2fM1d91RZCWjGvbm26B-AhMtRoqcIrNi0NFaJFpMIopDR8GCltls-aNQc8wEXSLm22uyeTWtrLJkKQ0brk1fwp_VCtVR7bVc3uK2KS",
               "width" : 5472
            }
         ],
         "place_id" : "ChIJcx1eHtiMGGAR72dNMqxrvKs",
         "plus_code" : {
            "compound_code" : "MPW2+5F 新宿区、東京都",
            "global_code" : "8Q7XMPW2+5F"
         },
         "price_level" : 2,
         "rating" : 3.5,
         "reference" : "ChIJcx1eHtiMGGAR72dNMqxrvKs",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 148,
         "vicinity" : "新宿区歌舞伎町１丁目２１−７ ヒューマックスパビリオン新宿アネックス1階"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6908823,
               "lng" : 139.7048821
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69236697989272,
                  "lng" : 139.7063052298927
               },
               "southwest" : {
                  "lat" : 35.68966732010728,
                  "lng" : 139.7036055701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新宿中央口店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 405,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/113561844911753201682\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEAMs4gBoseULauGAJRPFCAZ_oksF6TuXG96v6fFlogDXdpfPKUL0DvcZuuf_SqNlyVvg9L84CR484ZkMehqBT8eznL5fE2QQmj9MkxyMyyC7ZTg5j4_mJGpTK9Ml8pccIm_SaMLWn8tSho4QcYitip7T002JTtU_NmY2jWgmEjXfMla",
               "width" : 720
            }
         ],
         "place_id" : "ChIJY3dffNqMGGAR7pK7JyBY7hg",
         "plus_code" : {
            "compound_code" : "MPR3+9X 新宿区、東京都",
            "global_code" : "8Q7XMPR3+9X"
         },
         "price_level" : 3,
         "rating" : 3.3,
         "reference" : "ChIJY3dffNqMGGAR7pK7JyBY7hg",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 191,
         "vicinity" : "新宿区新宿３丁目３−２ メトロプラザ3 ビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6952578,
               "lng" : 139.7003642
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69659837989272,
                  "lng" : 139.7017522798927
               },
               "southwest" : {
                  "lat" : 35.69389872010727,
                  "lng" : 139.6990526201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 西武新宿駅前店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 405,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/100132825924714086885\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEDQTmqaeAkhqIhsnLScizDHtEjFJ8J5ezPUwLwBztFZyS_DyIsyV1Mr5-my6FkOJ9jRjI_T5zBDdL5u6FvLyyhA3Z6_rN2WFNMDPOiGVs33aoyo2PjCM3g6hDP661L6FZF-9xdVzLLQkBfeZt2VwmKVa6mEwNokqUEpl76aO8qX8kqA",
               "width" : 720
            }
         ],
         "place_id" : "ChIJWWGnm9eMGGARlF96M57WhRc",
         "plus_code" : {
            "compound_code" : "MPW2+44 新宿区、東京都",
            "global_code" : "8Q7XMPW2+44"
         },
         "price_level" : 3,
         "rating" : 3.7,
         "reference" : "ChIJWWGnm9eMGGARlF96M57WhRc",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 57,
         "vicinity" : "新宿区歌舞伎町１丁目２８−１ 歌舞伎町１丁目Ｂ＆Ｖビル"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6921613,
               "lng" : 139.7058724
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69354817989272,
                  "lng" : 139.7071251798927
               },
               "southwest" : {
                  "lat" : 35.69084852010727,
                  "lng" : 139.7044255201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケルーム歌広場 新宿三丁目店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3648,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/106839537545480040785\"\u003eカラオケルーム歌広場 カラNET２４新宿靖国通り店\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBgLe6BG7nYRlr_gHcRirbRdj2RIDhksh5PNnRUR-nHv2sVCivEu8YbNuAdgXvFOo105nVGHrYk89_8HNXD-Vpl2zCfzKoMxNKWHNzuUob36olt-xW0XcveL6LW_s-tZ9uQfmVolhPvRIsbDIj1SZ90pV0IkyYpyLmHK4nkHZEWXsZ1",
               "width" : 5472
            }
         ],
         "place_id" : "ChIJU_gPhduMGGAR13DJhNilVmI",
         "plus_code" : {
            "compound_code" : "MPR4+V8 新宿区、東京都",
            "global_code" : "8Q7XMPR4+V8"
         },
         "price_level" : 2,
         "rating" : 3.2,
         "reference" : "ChIJU_gPhduMGGAR13DJhNilVmI",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 259,
         "vicinity" : "新宿区新宿３丁目１３−５ 新宿３丁目ビル５F"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.695119,
               "lng" : 139.6988521
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69641957989272,
                  "lng" : 139.7000832298927
               },
               "southwest" : {
                  "lat" : 35.69371992010728,
                  "lng" : 139.6973835701072
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケ館 新宿大ガード店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 400,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/100326965129161987220\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEBYy58FcojoVjcnEq-qat12TFEEoHjo8tYNFLxiZylKlD26GYp2pTBJuJvbG5fOV-QM-ZdqPDOCRlziDGV0lah56UQUw4AFmI9MDjSEaSOi3LDn81jPaXMH94_alDclGkz25xvBK92Lc3TvDtuEYr1uIebfROLjJadcQVZOJ5jgG2dM",
               "width" : 650
            }
         ],
         "place_id" : "ChIJMw-DtteMGGARYy5_cdqO7Y8",
         "plus_code" : {
            "compound_code" : "MMWX+2G 新宿区、東京都",
            "global_code" : "8Q7XMMWX+2G"
         },
         "price_level" : 3,
         "rating" : 3.3,
         "reference" : "ChIJMw-DtteMGGARYy5_cdqO7Y8",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 160,
         "vicinity" : "新宿区西新宿７丁目１−７ 新宿ダイカンプラザA館"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6936058,
               "lng" : 139.702297
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69508182989272,
                  "lng" : 139.70484265
               },
               "southwest" : {
                  "lat" : 35.69238217010728,
                  "lng" : 139.70144845
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケまねきねこ新宿靖国通り店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 2526,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/109960950428579853458\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uED5bokK8GKPKSo8uT6ynB0nIsqljNdZSxTpSHVtihJjMPg3XqE-cDs6f8zrEEQT-4dcBbSMHJMxwcORTnB2mLmV7RRa54PrMV-XKSuArT7CJ6ImMJpcz1bRnCq6PAbCBSS1qSwwtOluN4lb1nDLfEaOF9k2xotJNv3iEkCsu7iRendw",
               "width" : 3372
            }
         ],
         "place_id" : "ChIJQT26TAKNGGARqsdETw4-uCk",
         "plus_code" : {
            "compound_code" : "MPV2+CW 新宿区、東京都",
            "global_code" : "8Q7XMPV2+CW"
         },
         "rating" : 4.5,
         "reference" : "ChIJQT26TAKNGGARqsdETw4-uCk",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 2,
         "vicinity" : "新宿区歌舞伎町１丁目６−２"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.695023,
               "lng" : 139.7013685
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69637282989272,
                  "lng" : 139.7027183298927
               },
               "southwest" : {
                  "lat" : 35.69367317010728,
                  "lng" : 139.7000186701073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "コロッケ倶楽部 歌舞伎町店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 1588,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/107379121600265349156\"\u003eKevin Sarmiento\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECd9QSwwn8DM0Mtbd7bNN1tzWkqfD9oPhfwy0Gu1eq0DSdFTqKPAT4UIQYgk5zoFKGCsWtEcjE7xdDbEjBnwTBUTIMNXX5vAGQ-HBMHXaGmD6cMbBaENhWsv_rEcVLeoslUy0O85E-t8aaP5cFNubUGI6KoHtFMLg4qS9ZMzPNb2_IV",
               "width" : 3264
            }
         ],
         "place_id" : "ChIJ___7J9iMGGARNNpNE27R6eU",
         "plus_code" : {
            "compound_code" : "MPW2+2G 新宿区、東京都",
            "global_code" : "8Q7XMPW2+2G"
         },
         "price_level" : 3,
         "rating" : 3.5,
         "reference" : "ChIJ___7J9iMGGARNNpNE27R6eU",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 50,
         "vicinity" : "新宿区歌舞伎町１丁目２１−１２ ギャラリーカドー"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6942477,
               "lng" : 139.7015952
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69559647989271,
                  "lng" : 139.7029971798927
               },
               "southwest" : {
                  "lat" : 35.69289682010727,
                  "lng" : 139.7002975201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケルーム歌広場 新宿歌舞伎町ゴジラロード店",
         "opening_hours" : {
            "open_now" : true
         },
         "photos" : [
            {
               "height" : 3648,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/103977285992054609044\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uEB6pDHPpDfGi6wU0mSmdwJtFzjQGSE9Sd2HffdmEm4ri0hzB2ObQqlXZxNpgIZoFwCKVWxgMQlXV6bNy8UcQ2zm7jyFcv58sIR97FklrgOP54nwow6P59sv8r6X0MSSQ-7ycHegiwbe7oyMcs_vTy9heQULoy7NTj_yAjiXM2wqM_R6",
               "width" : 5472
            }
         ],
         "place_id" : "ChIJS5G6m8qNGGAR_6RZmaXcefY",
         "plus_code" : {
            "compound_code" : "MPV2+MJ 新宿区、東京都",
            "global_code" : "8Q7XMPV2+MJ"
         },
         "rating" : 4,
         "reference" : "ChIJS5G6m8qNGGAR_6RZmaXcefY",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 6,
         "vicinity" : "新宿区歌舞伎町１丁目１７−１０ 7階"
      },
      {
         "business_status" : "OPERATIONAL",
         "geometry" : {
            "location" : {
               "lat" : 35.6909793,
               "lng" : 139.7057566
            },
            "viewport" : {
               "northeast" : {
                  "lat" : 35.69230242989272,
                  "lng" : 139.7071665798927
               },
               "southwest" : {
                  "lat" : 35.68960277010728,
                  "lng" : 139.7044669201073
               }
            }
         },
         "icon" : "https://maps.gstatic.com/mapfiles/place_api/icons/v1/png_71/generic_business-71.png",
         "icon_background_color" : "#7B9EB0",
         "icon_mask_base_uri" : "https://maps.gstatic.com/mapfiles/place_api/icons/v2/generic_pinlet",
         "name" : "カラオケBanBan新宿三丁目店",
         "opening_hours" : {
            "open_now" : false
         },
         "photos" : [
            {
               "height" : 2736,
               "html_attributions" : [
                  "\u003ca href=\"https://maps.google.com/maps/contrib/103791182819889200238\"\u003eA Google User\u003c/a\u003e"
               ],
               "photo_reference" : "Aap_uECZBQSm9vEwlOzSn8x-JZObxEa6yec9rax88cIp61_RUQ6GHD5BPkSQnsRtdLYSsotaVPD7pljoXp6ci81ObEzS98sWHmhTJ5lfvoPvrgODqlscjQlM305I__Dx1cwtFMLUFjzFrEa6YvggSMIY2lAZxGyDWqsvckttpBk64Wj62t-N",
               "width" : 3648
            }
         ],
         "place_id" : "ChIJZTZyZqWNGGARQluigA0ihGo",
         "plus_code" : {
            "compound_code" : "MPR4+98 新宿区、東京都",
            "global_code" : "8Q7XMPR4+98"
         },
         "rating" : 3.7,
         "reference" : "ChIJZTZyZqWNGGARQluigA0ihGo",
         "scope" : "GOOGLE",
         "types" : [ "point_of_interest", "establishment" ],
         "user_ratings_total" : 3,
         "vicinity" : "新宿区新宿３丁目６−１４ 新世界ビル"
      }
   ],
   "status" : "OK"
}
